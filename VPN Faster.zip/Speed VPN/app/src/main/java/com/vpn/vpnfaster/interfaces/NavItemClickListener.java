package com.vpn.vpnfaster.interfaces;

public interface NavItemClickListener {
    void clickedItem(int index);
}
