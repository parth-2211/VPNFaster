package com.vpn.vpnfaster.interfaces;

import com.vpn.vpnfaster.model.Server;

public interface ChangeServer {
    void newServer(Server server);
}
